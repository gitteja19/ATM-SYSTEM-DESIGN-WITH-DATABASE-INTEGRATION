
#include "atmLib.h"



int main(){

	//local vars
	int fd,type;
	char buf[100];
	Acc *db=NULL;
	//sync
	syncData(&db);
#ifdef DBG
	puts("synced");
#endif
	//initiate uart
	fd=initSerial();
#ifdef DBG
	puts("super loop");
#endif
	
	//recv from uart and do necessary
	while(1){
		rx_str(fd,buf,sizeof(buf));
		/*
		puts("->");
		fgets(buf,sizeof(buf),stdin);
		buf[strlen(buf)-1]=0;
		fd=1;
		*/
		if(!isMsgOk(buf))continue;
		//#<opt>:<data>$
		switch(buf[1]){
			//check rfid
			case 'C':checkRFID(db,fd,buf);
				 break;
			//verify pin
			case 'V':verifyPin(db,fd,buf);
				 break;
			//do action
			case 'A':puts("acting.");
				 act(db,fd,buf);
				 break;
			//connection check
			case 'X':tx_str(fd,"@X:LINEOK$");
				 break;
			case 'Q':
				 saveData(db);
				 saveFile(db);
				 puts("data saved");
				 break;
		}
	}
}

