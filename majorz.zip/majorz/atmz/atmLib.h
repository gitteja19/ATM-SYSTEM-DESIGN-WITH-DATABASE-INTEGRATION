

#ifndef _ATMLIB_H
#define _ATMLIB_H

#define DBG
//#define INT

#include<stdio.h>
#include<stdlib.h>
#include<stdint.h>
#include<string.h>
#include<unistd.h>
#include<fcntl.h>
#include<errno.h>
#include<time.h>
#include<termios.h>

#define MAX_DEPOSIT	30000 //30K
#define MAX_WITHDRAW	30000 //30k
#define MAX_TRANSFER 	100000//1lk

#define NAME_LEN 30
#define MAX_PASS_LEN 20
#define MAX_USRN_LEN 20

#define BLOCKED 0
#define	ACTIVE  1

#define WITHDRAW 1
#define DEPOSIT  2
#define TRANSFER_IN 3
#define TRANSFER_OUT 4

#define CAPS(ch) (ch &=~(32))

//decorations
#define RESET   "\033[0m"
#define BBLACK  "\033[1;30m"
#define BRED    "\033[1;31m"
#define BGREEN  "\033[1;32m"
#define BYELLOW "\033[1;33m"
#define BBLUE   "\033[1;34m"
#define BPINK   "\033[1;35m"
#define BCYAN   "\033[1;36m"
#define BWHITE  "\033[1;37m"


typedef unsigned long long int u64;
typedef double f64;

// "%lu,%lf,%c",id,amt,type
// "%lu,%s,%lu,%s,%s,%s,%s,%d,%lf,%lu",num,name,phno,usrName,pass,rfid,pin,cardStat,bal,tranCnt
typedef struct A{
        f64 amt;
        u64 id;
	char type;

	struct A *nxt;
}Tran;

// "%lu,%s,%lu,%s,%s,%s,%s,%d,%lf,%lu",num,name,phno,usrName,pass,rfid,pin,cardStat,bal,tranCnt
typedef struct B{
        u64 num;//unique acc num/id
        f64 bal;//bank balance
        u64 phno;//mobile
        char usrName[MAX_USRN_LEN];
	char pass[MAX_PASS_LEN];
	char rfid[9];
	char pin[5];
	int cardStat;//1-active,0-block
        char name[30];//name
        
	Tran *tranHist;
        u64 tranCnt;
	struct B *nxt;
}Acc;


int initSerial();
void endSerial(const int fd);
int tx_char(const int fd,const char ch);
int tx_str(const int fd,const char *str);
char rx_char(const int fd);
void rx_str(const int fd,char *str,size_t len);

int isMsgOk(const char *buf);
void checkRFID(Acc *head,const int fd,const char *buf);
void verifyPin(Acc *head,const int fd,const char *buf);
void act(Acc *head,const int fd,const char *buf);
double extAmt(const char *buf);
void deposit(const int fd,Acc *usr,const f64 amt);
void withdraw(const int fd,Acc *usr,const f64 amt);
void balance(const int fd,Acc *usr);
void pinChange(const int fd,Acc *usr,const char *pin);
void miniStatement(const int fd,Acc *usr,char txn);
void addTran(Acc *usr,f64 amt,char type);
u64 getTranId(Acc *usr);
u64 getTimeStamp(void);
void checkMC(const int fd);
void syncData(Acc **head);
void saveData(Acc *head);
void saveFile(Acc *head);

Acc* getAcc(Acc *head,const char *rfid);



#endif

