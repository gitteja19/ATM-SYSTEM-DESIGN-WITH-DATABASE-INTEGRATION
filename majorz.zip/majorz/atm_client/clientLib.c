
#include "clientLib.h"

#define BAUD B9600

int initSerial(void){
	int fd;
	struct termios opt;
	//open serial
	//fd=open("/dev/ttyUSB0",O_RDWR|O_NOCTTY| O_NDELAY);
	fd=open("/dev/ttyUSB0",O_RDWR|O_NOCTTY);
	if(fd==-1){
		perror("open");
		exit(1);
	}
	//make read a blocking func
	fcntl(fd,F_SETFL,0);
	//fcntl(fd,F_SETFL,FNDELAY);//non blocking
	// Get and modify current options:

	tcgetattr (fd, &opt) ;

	cfmakeraw   (&opt) ;
	cfsetispeed (&opt, BAUD) ;
	cfsetospeed (&opt, BAUD) ;

	opt.c_cflag |= (CLOCAL | CREAD) ;
	opt.c_cflag &= ~PARENB ;
	opt.c_cflag &= ~CSTOPB ;
	opt.c_cflag &= ~CSIZE ;
	opt.c_cflag |= CS8 ;
	opt.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG) ;
	opt.c_oflag &= ~OPOST ;

	tcsetattr (fd, TCSANOW | TCSAFLUSH, &opt) ;

	usleep (10000) ;	// 10mS
	return fd;
}

void sendMsg(const char *str){
	write(dev_fd,str,strlen(str));
	//write("\r\n",2)		
}

void recvMsg(char *str){	
	int i=0;
	char ch;
	while(1){
		read(dev_fd,&ch,1);
		str[i++]=ch;
		if(ch=='\n'){
			str[i]='\0';
			break;
		}
	}
}

void sendFrame(const char *str){
	send(soc_fd,str,strlen(str),0);
}

void recvFrame(char *str){
	int i=0;
	char ch;
	while(1){
		recv(soc_fd,&ch,1,0);
		str[i++]=ch;
		if(ch=='\n'){
			str[i]='\0';
			break;
		}
	}
}

void off(int sig){
	sendFrame("#POWEROFF$\r\n");
	puts("Powering off..");
	exit(0);
}

