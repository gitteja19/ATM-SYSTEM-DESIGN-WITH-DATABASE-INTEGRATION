

#include "clientLib.h"

int soc_fd = -1, dev_fd = -1;
int server_port;
char *server_ip;

pthread_mutex_t conn_lock = PTHREAD_MUTEX_INITIALIZER;
volatile int is_connected = 0;

void* uart_to_server(void* arg) {
    char buf[100];
    while (1) {
        if (dev_fd < 0 || soc_fd < 0) {
            sleep(1);
            continue;
        }

        recvMsg(buf);

        pthread_mutex_lock(&conn_lock);
        if (is_connected)
            sendFrame(buf);
        pthread_mutex_unlock(&conn_lock);
    }
    return NULL;
}

void* server_to_uart(void* arg) {
    char buf[100];
    while (1) {
        if (soc_fd < 0 || dev_fd < 0) {
            sleep(1);
            continue;
        }

        recvFrame(buf);

        pthread_mutex_lock(&conn_lock);
        if (is_connected)
            sendMsg(buf);
        pthread_mutex_unlock(&conn_lock);
    }
    return NULL;
}

void* connection_manager(void* arg) {
    struct sockaddr_in saddr;

    while (1) {
        if (dev_fd < 0) {
            dev_fd = initSerial();
            if (dev_fd > 0) {
                printf("Serial device reconnected\n");
            }
        }

        if (soc_fd < 0) {
            soc_fd = socket(AF_INET, SOCK_STREAM, 0);
            if (soc_fd < 0) {
                perror("socket");
                sleep(2);
                continue;
            }

            saddr.sin_family = AF_INET;
            saddr.sin_port = htons(server_port);
            saddr.sin_addr.s_addr = inet_addr(server_ip);

            if (connect(soc_fd, (struct sockaddr *)&saddr, sizeof(saddr)) == 0) {
                pthread_mutex_lock(&conn_lock);
                is_connected = 1;
                pthread_mutex_unlock(&conn_lock);
                puts("Client connected to server.");
            } else {
                perror("connect");
                close(soc_fd);
                soc_fd = -1;
            }
        }

        sleep(2);
    }
    return NULL;
}

/*
void off(int sig) {
    pthread_mutex_lock(&conn_lock);
    if (is_connected)
        sendFrame("#POWEROFF$\r\n");
    pthread_mutex_unlock(&conn_lock);
    puts("Powering off..");
    close(soc_fd);
    close(dev_fd);
    exit(0);
}
*/

int main(int argc, char **argv) {
    if (argc != 3) {
        printf("[USE]./client servPort servIP\n");
        exit(1);
    }

    server_port = atoi(argv[1]);
    server_ip = argv[2];

    signal(SIGINT, off);

    pthread_t t1, t2, t3;
    pthread_create(&t1, NULL, uart_to_server, NULL);
    pthread_create(&t2, NULL, server_to_uart, NULL);
    pthread_create(&t3, NULL, connection_manager, NULL);

    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    pthread_join(t3, NULL);

    return 0;
}

