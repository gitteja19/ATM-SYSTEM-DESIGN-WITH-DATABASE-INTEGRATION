
#ifndef _CLIENT_LIB_H
#define _CLIENT_LIB_H

#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <termios.h>
#include <unistd.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <signal.h>
#include <pthread.h>

extern int dev_fd,soc_fd,server_port;
extern char *server_ip;

extern pthread_mutex_t conn_lock;
extern volatile int is_connected;

void sendMsg(const char*);
void recvMsg(char*);

void sendFrame(const char*);
void recvFrame(char*);

void off(int);

int initSerial(void);


#endif
