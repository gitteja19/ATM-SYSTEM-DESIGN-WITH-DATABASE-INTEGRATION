

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "clientLib.h"

int soc_fd,dev_fd;

int main(int argc, char**argv){

	long c_sz;
	size_t len;
	struct sockaddr_in saddr;
	char buf[100];
	
	if(argc!=3){
		printf("[USE]./client servPort servIP\n");
		exit(1);

	}
	signal(SIGINT,off);

	dev_fd=initSerial();
	//socket 0-tcp/ip
	soc_fd=socket(AF_INET,SOCK_STREAM,0);
	if(soc_fd<0){
		perror("socket");
		exit(1);
	}

	puts("Server socket created");

	//assigning local addr to socket
	saddr.sin_family=AF_INET;
	saddr.sin_port=htons(atoi(argv[1]));//server port 
	saddr.sin_addr.s_addr=inet_addr(argv[2]);//server ip

	//initiate 3 way handshake
	if(connect(soc_fd,(const struct sockaddr *)&saddr,sizeof(saddr))<0){
		perror("connect");
		exit(1);
	}
	puts("client connected to server.");

	while(1){
		//wait for uart 
		recvMsg(buf);
		/*
		if(!strcmp(buf,"#X:LINEOK$")){
			write(dev_fd,"@X:LINEOK$\r\n",12);
			continue;
		}
		*/
		//send to server
		sendFrame(buf);
		//wait for server
		recvFrame(buf);
		//send to uart
		sendMsg(buf);
	}
	close(soc_fd);
	close(dev_fd);
}
