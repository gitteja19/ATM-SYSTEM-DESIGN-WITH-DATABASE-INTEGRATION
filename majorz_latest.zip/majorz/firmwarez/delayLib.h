#ifndef _DELAYLIB_H
#define _DELAYLIB_H
 

#include "types.h"

void delayS(u32);
void delayMs(u32 dly);
void delayUs(u32 dly);


#endif
