
#ifndef _RFIDLIB_H
#define _RFIDLIB_H

#include "types.h"


void getCardNo(s8 *buf);
s32 isCardNoOk(s8 *buf);


#endif

