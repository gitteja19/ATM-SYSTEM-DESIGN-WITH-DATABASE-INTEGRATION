
#include "atmLib.h"

Acc *db=NULL;
int mst_fd,tidCnt;
pthread_mutex_t m1;


int main(int argc,char **argv){
	//local vars
	int cli_fd,type;
        unsigned int c_sz;
        struct sockaddr_in saddr,caddr;
	if(argc!=2){
		printf("[USE]./server serPort\n");
		exit(1);

	}
	pthread_mutex_init(&m1,NULL);
	signal(SIGINT,shutdown_srv);
	signal(SIGQUIT,shutdown_srv);
	//sync
	syncData(&db);
#ifdef DBG
	puts("synced");
#endif
	//tcp/ip
        //socket 0-tcp/ip
        mst_fd=socket(AF_INET,SOCK_STREAM,0);
        if(mst_fd<0){
                perror("socket");
                exit(1);
        }

#ifdef DBG
        puts("Server socket created");
#endif

        //assigning local addr to socket
        saddr.sin_family=AF_INET;
        saddr.sin_port=htons(atoi(argv[1]));//htons()-cnvrt little endian 2 Big endian
        saddr.sin_addr.s_addr=inet_addr("0.0.0.0");

        //typecastes because same func for multiple protocols
        if(bind(mst_fd,(const struct sockaddr*)&saddr,sizeof(saddr))<0){
                perror("bind");
                exit(1);
        }
#ifdef DBG
        puts("Assigned local addr to the socket");
#endif

        //listen
        //second arg- no.of pending queues

        if(listen(mst_fd,1)<0){
                perror("listen");
                exit(1);
        }

        c_sz=sizeof(caddr);
	pthread_t tid;
	while(1){
                cli_fd=accept(mst_fd,(struct sockaddr*)&caddr,&c_sz);
                if(cli_fd==-1){
                        perror("accept");
                        continue;
		}
		ARG* arg = malloc(sizeof(ARG));
		arg->fd = cli_fd;
		memmove(&(arg->caddr), &caddr, sizeof(caddr));
		
		pthread_create(&tid, NULL, serverFunc, arg);
		tidCnt++;
                printf("%s:%hu -client connected!!\n",inet_ntoa(caddr.sin_addr),ntohs(caddr.sin_port));
        
	}
	/*
	saveData(db);
        saveFile(db);
	*/
}

void* serverFunc(void *in){

#ifdef DBG
	puts("super loop");
#endif
	pthread_detach(pthread_self());

	char buf[100];
	ARG *arg = (ARG *)in;  // Correct cast
	int cli_fd = arg->fd;
	struct sockaddr_in cAddr;
	memmove(&cAddr, &(arg->caddr), sizeof(cAddr));
	free(arg);	
	//recv from uart and do necessary
	while(1){
		recvFrame(cli_fd,buf,sizeof(buf));

		if(!isMsgOk(buf) || (!strcmp(buf," Welcome To ATM ")))continue;


		if(strstr(buf,"#POWEROFF$")){
			pthread_mutex_lock(&m1);
			saveData(db);
			saveFile(db);
			pthread_mutex_unlock(&m1);
			close(cli_fd);
			tidCnt--;
			printf("%s:%hu -client disconnected!!\n",inet_ntoa(cAddr.sin_addr),ntohs(cAddr.sin_port));
			pthread_exit(NULL);
		}
		//#<opt>:<data>$
		switch(buf[1]){
			//check rfid
			case 'C':checkRFID(db,cli_fd,buf);
				 break;
			//verify pin
			case 'V':verifyPin(db,cli_fd,buf);
				 break;
			//do action
			case 'A':puts("acting.");
				 act(db,cli_fd,buf);
				 break;
			//connection check
			case 'X':
				 //tx_str(fd,"@X:LINEOK$");
				 sendFrame(cli_fd,"@X:LINEOK$");
				 break;
			case 'Q':
				 //saveData(db);
				 //saveFile(db);
				 puts("data saved");
				 break;
		}
	}
}


