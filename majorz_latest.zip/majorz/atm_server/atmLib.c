
#include "atmLib.h"

#define BAUD B9600





void shutdown_srv(int sig) {


	if(tidCnt){
		printf("%d - Client Sessions still online!!",tidCnt);
		return;
	}

	printf("\n[Server] Shutting down gracefully...\n");
	pthread_mutex_lock(&m1);
	saveData(db);
	saveFile(db);
	pthread_mutex_unlock(&m1);
	close(mst_fd);
	exit(0);
}

/*
int initSerial(void){

	int fd;
	struct termios opt;
	//open serial
	//fd=open("/dev/ttyUSB0",O_RDWR|O_NOCTTY| O_NDELAY);
	fd=open("/dev/ttyUSB0",O_RDWR|O_NOCTTY);
	if(fd==-1){
		perror("open");
		exit(1);
	}
	//make read a blocking func
	fcntl(fd,F_SETFL,0);
	//fcntl(fd,F_SETFL,FNDELAY);//non blocking
	// Get and modify current options:

	tcgetattr (fd, &opt) ;

	cfmakeraw   (&opt) ;
	cfsetispeed (&opt, BAUD) ;
	cfsetospeed (&opt, BAUD) ;

	opt.c_cflag |= (CLOCAL | CREAD) ;
	opt.c_cflag &= ~PARENB ;
	opt.c_cflag &= ~CSTOPB ;
	opt.c_cflag &= ~CSIZE ;
	opt.c_cflag |= CS8 ;
	opt.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG) ;
	opt.c_oflag &= ~OPOST ;

	tcsetattr (fd, TCSANOW | TCSAFLUSH, &opt) ;

	usleep (10000) ;	// 10mS
	return fd;
}

void flushSerial (const int fd)
{
	tcflush (fd, TCIOFLUSH) ;
}

void endSerial(const int fd){
	close(fd);
}

int tx_char(const int fd,const char ch){
	return write(fd,&ch,1);
}

int tx_str(const int fd,const char *str){
	write(fd,str,strlen(str));
	write(fd,"\r\n",2);
#ifdef DBG
	printf("DBG_TX:%s\n",str);
#endif
}
*/
void sendFrame(const int fd,const char *str){
	send(fd,str,strlen(str),0);
        send(fd,"\r\n",2,0);
#ifdef DBG
        printf("DBG_TX:%s\n",str);
#endif

}
/*
char rx_char(const int fd){
	char ch;
	if(read(fd,&ch,1)!=1)return -1;
	return ch;
}

void rx_str(const int fd,char *str,size_t len){
	int i=0,j=0;
	char ch;
	for(;i<len-1;i++){
		j=read(fd,&ch,1);
		if(j==-1){
			printf("i=%d\n",i);
			perror("read_str");
			exit(1);
		}else if(j==0){
			i--;
			continue;
		}
		str[i]=ch;
		if(ch=='\n')break;
	}
	str[i-1]='\0';//'\r' -> 0
#ifdef DBG      
	printf("DBG_RX:%s\n",str);
#endif
}
*/
void recvFrame(const int fd,char *str,size_t len){
        int i=0,j=0;
        char ch;
        for(;i<len-1;i++){
                j=recv(fd,&ch,1,0);
                if(j==-1){
                        printf("i=%d\n",i);
                        perror("read_str");
                        exit(1);
                }else if(j==0){
                        i--;
                        continue;
                }
                str[i]=ch;
                if(ch=='\n')break;
        }
        str[i-1]='\0';//'\r' -> 0
#ifdef DBG
        printf("DBG_RX:%s\n",str);
#endif
}

int isMsgOk(const char *buf){
	if((buf[0]=='#')&&(buf[strlen(buf)-1]=='$'))return 1;
	return 0;
}
void checkRFID(Acc *head,const int fd,const char *buf){
	//#C:<rfid>$
	//check rfid in database
	char rfid[9];
	char temp[32];
	strncpy(rfid,buf+3,8);
	rfid[8]='\0';
	pthread_mutex_lock(&m1);
	Acc *usr=getAcc(head,rfid);
	pthread_mutex_unlock(&m1);
#ifdef INT
	checkMC(fd);
#endif
	if(usr){
		//card stat
	pthread_mutex_lock(&m1);
		if(usr->cardStat){
			sprintf(temp,"@OK:ACTIVE:%s$",usr->usrName);
			//tx_str(fd,temp);
			sendFrame(fd,temp);

		}else{
			sendFrame(fd,"@ERR:BLOCK$");
		}
	pthread_mutex_unlock(&m1);
	}else{
		sendFrame(fd,"@ERR:INVALID$");
	}
}

void verifyPin(Acc *head,const int fd,const char *buf){
	//#V:<rfid>:<pin>$
	//verify rfid with pin
	char rfid[9];	
	char pin[5];

	strncpy(rfid,buf+3,8);
	rfid[8]='\0';
	strncpy(pin,buf+12,4);
	pin[4]='\0';

	pthread_mutex_lock(&m1);
	Acc *usr=getAcc(head,rfid);
	pthread_mutex_unlock(&m1);
#ifdef INT
	checkMC(fd);
#endif
	pthread_mutex_lock(&m1);
	if(!strcmp(pin,usr->pin)){
		sendFrame(fd,"@OK:MATCHED$");

	}else{
		sendFrame(fd,"@ERR:WRONG$");

	}	
	pthread_mutex_unlock(&m1);
}

void act(Acc *head,const int fd,const char *buf){
	//#A:WTD:<rfid>:<amt>$	-> @OK:DONE$,@ERR:LOWBAL$,@ERR:NEGAMT$,@ERR:MAXAMT$
	//#A:DEP:<rfid>:<amt>$	-> @OK:DONE$,@ERR:NEGAMT$,@ERR:MAXAMT$
	//#A:BAL:<rfid>$	-> @OK:BAL=<amt>$
	//#A:PIN:<rfid>:<pin>$	-> @OK:DONE$
	//#A:MST:<rfid>:<txNo>$ -> @TXN:<type>:<ddmmyyyyhhmm>:<amt>$
	//#A:BLK:<rfid>$	-> @OK:DONE$
	//#A:TNF:<rfid>:<amt>:<rfid>$	

	char rfid[9];
	char req[4];
	char pin[5];
	double amt=0;
	char txn=0;

	//extract rfid
	strncpy(rfid,buf+7,8);
	rfid[8]='\0';
	//get Acc
	
	pthread_mutex_lock(&m1);
	Acc *usr=getAcc(head,rfid);
	pthread_mutex_unlock(&m1);
	//extract req
	strncpy(req,buf+3,3);
	req[3]='\0';

	printf("req=%s,rfid=%s\n",req,rfid);

	pthread_mutex_lock(&m1);
	if(!strcmp(req,"WTD")){
		amt=extAmt(buf);
		withdraw(fd,usr,amt);
	}else if(!strcmp(req,"DEP")){
		amt=extAmt(buf);
		deposit(fd,usr,amt);
	}else if(!strcmp(req,"BAL")){
		balance(fd,usr);
	}else if(!strcmp(req,"MST")){
		//mini statement
		txn=buf[16]-'0';
		miniStatement(fd,usr,txn);
	}else if(!strcmp(req,"TNF")){
		char target_rfid[9];
		double amt;
		strncpy(target_rfid, buf+16, 8); // careful: offset may need to be adjusted
		amt = extAmt(buf); // assumes target_rfid is fixed 8 chars

		Acc *target = getAcc(head, target_rfid);
		if(!target){
			sendFrame(fd, "@ERR:TARGETNF$");
		} else if(amt <= 0){
			sendFrame(fd, "@ERR:NEGAMT$");
		} else if(usr->bal < amt){
			sendFrame(fd, "@ERR:LOWBAL$");
		} else {
			usr->bal -= amt;
			target->bal += amt;
			addTran(usr, -amt, TRANSFER_OUT);
			addTran(target, amt, TRANSFER_IN);
			sendFrame(fd, "@OK:DONE$");
		}
	}else if(!strcmp(req,"PIN")){
		strncpy(pin,buf+16,4);
		pinChange(fd,usr,pin);
	}else if(!strcmp(req,"BLK")){
		usr->cardStat=BLOCKED;
#ifdef INT
		checkMC(fd);
#endif
		sendFrame(fd,"@OK:DONE$");
	}else{

	}
	pthread_mutex_unlock(&m1);
}

double extAmt(const char *buf){
	char dup[20];
	strcpy(dup,buf+16);
	dup[strlen(dup)-1]='\0';
	return atof(dup);
}

Acc* getAcc(Acc *head,const char *rfid){
	while(head){
		if(!strcmp(rfid,head->rfid)) break;
		head=head->nxt;
	}
	return head;
}

///
void deposit(const int fd,Acc *usr,const f64 amt){
	//#A:DEP:<rfid>:<amt>$	-> @OK:DONE$,@ERR:NEGAMT$,@ERR:MAXAMT$
#ifdef INT
	checkMC(fd);
#endif
	if(amt<=0){
		sendFrame(fd,"@ERR:NEGAMT$");

	}else if(amt<MAX_DEPOSIT){
		usr->bal += amt;
		//update 2 transc
		addTran(usr,+amt,DEPOSIT);
		sendFrame(fd,"@OK:DONE$");

	}else{
		sendFrame(fd,"@ERR:MAXAMT$");

	}
}
///

///
void withdraw(const int fd,Acc *usr,const f64 amt){
	//#A:WTD:<rfid>:<amt>$	-> @OK:DONE$,@ERR:LOWBAL$,@ERR:NEGAMT$,@ERR:MAXAMT$
#ifdef INT
	checkMC(fd);
#endif
	if(amt<=0){
		sendFrame(fd,"@ERR:NEGAMT$");
	}else if(amt<MAX_WITHDRAW){
		if(amt<=(usr->bal)){
			usr->bal -= amt;
			//update 2 transc
			addTran(usr,-amt,WITHDRAW);//1
			sendFrame(fd,"@OK:DONE$");

		}else{
			sendFrame(fd,"@ERR:LOWBAL$");

		}
	}else{
		sendFrame(fd,"@ERR:MAXAMT$");

	}
}
///
void balance(const int fd,Acc *usr){
	//#A:BAL:<rfid>$	-> @OK:BAL=<amt>$
	puts("in bal.");
	char buf[50];
	sprintf(buf,"@OK:BAL=%.2lf$",usr->bal);
#ifdef INT
	checkMC(fd);
#endif
	sendFrame(fd,buf);	

}
///
void pinChange(const int fd,Acc *usr,const char *pin){
	//#A:PIN:<rfid>:<pin>$	-> @OK:DONE$
	strcpy(usr->pin,pin);
#ifdef INT
	checkMC(fd);
#endif
	sendFrame(fd,"@OK:DONE$");

}
///
void miniStatement(const int fd,Acc *usr,char txn){
	//#A:MST:<rfid>:<txNo>$ -> @TXN:<type>:<ddmmyyyyhhmm>:<amt>$
	char buf[70];
	u64 dum;
	double amt;
	unsigned int dd,mon,yy,hh,mm;
	if(txn<=usr->tranCnt){
		Tran *t=usr->tranHist;
		while(--txn){
			t=t->nxt;
		}
		dum=(t->id)/100000;
		mm=dum%100;
		dum/=100;
		hh=dum%100;
		dum/=100;
		dd=dum%100;
		dum/=100;
		mon=dum%100;
		dum/=100;
		yy=dum;
		amt=t->amt;
		amt=(amt<0)?-amt:amt;
		sprintf(buf,"@TXN:%d:%02u/%02u/%04u %02u:%02u:%.2lf$",t->type,dd,mon,yy,hh,mm,amt);
#ifdef INT
		checkMC(fd);
#endif
		sendFrame(fd,buf);
	}else{
#ifdef INT
		checkMC(fd);
#endif
		sendFrame(fd,"@TXN:7:0:0$");
	}
}
///
void addTran(Acc *usr,f64 amt,char type){
	Tran *new=calloc(1,sizeof(Tran));
	new->amt=amt;
	new->id =getTranId(usr);
	new->type=type;
	new->nxt=NULL;

	new->nxt=usr->tranHist;
	usr->tranHist=new;

	(usr->tranCnt)++;
}

u64 getTranId(Acc *usr){
	//17 digit unq TranID
	srand(usr->num);
	return getTimeStamp()*1000 +(rand()%1000);
}
///
u64 getTimeStamp(void){
	time_t rawtime;
	struct tm *timeinfo;

	// Get current UTC time
	time(&rawtime);

	// Convert to IST (UTC +5:30)
	timeinfo =localtime(&rawtime);

	// Format as YYYYMMDDHHMMSS (14-digit ID)
	u64 timeStamp =
		(timeinfo->tm_year+1900)*10000000000ULL+
		(timeinfo->tm_mon+1)*100000000ULL+
		timeinfo->tm_mday*1000000ULL+
		timeinfo->tm_hour*10000ULL+
		timeinfo->tm_min *100ULL+
		timeinfo->tm_sec;

	return timeStamp;
}
//
/*
#ifdef INT
checkMC();
#endif

*/
void checkMC(const int fd){
	char buf[20];
	while(1){
		sendFrame(fd,"@Y:LINEOK$");
		recvFrame(fd,buf,sizeof(buf));
		if(!strcmp(buf,"#Y:LINEOK$"))break;
	}
}
//
void syncData(Acc **head){
	FILE *fp=fopen("../dataz/Db.csv","r");
	int d;
	if(!fp)return;
	puts("syncing");
	Acc temp,*tail=NULL;

	temp.nxt=NULL;
	temp.tranHist=NULL;
	temp.tranCnt=0;
	while(fscanf(fp,"%llu,%[^,],%llu,%[^,],%[^,],%[^,],%[^,],%d,%lf,%llu",&(temp.num),temp.name,&(temp.phno),temp.usrName,temp.pass,temp.rfid,temp.pin,&(temp.cardStat),&(temp.bal),&(temp.tranCnt))==10){


		Acc *new =calloc(1,sizeof(Acc));
		memmove(new,&temp,sizeof(Acc));
		if(!(*head))*head=new;
		if(tail)tail->nxt=new;
		tail=new;

		//save bank statement
		char spName[30];
		sprintf(spName,"../dataz/%llu.csv",new->num);
		FILE *sp=fopen(spName,"r");
		if(!sp)continue;
		Tran *th=NULL,*tt=NULL,tm;
		int cnt=0;
		tm.nxt=NULL;
		while(fscanf(sp,"%llu,%lf,%c",&(tm.id),&(tm.amt),&(tm.type))==3){
			Tran *c=malloc(sizeof(Tran));
			cnt++;
			memmove(c,&tm,sizeof(Tran));
			if(!th)th=c;
			if(tt)tt->nxt=c;
			tt=c;
		}
		new->tranHist=th;
		new->tranCnt=cnt;
		fclose(sp);
	}

	fclose(fp);
}

//
void saveData(Acc *head){

	FILE *fp=fopen("../dataz/Db.csv","w");

	while(head){
		fprintf(fp,"%llu,%s,%llu,%s,%s,%s,%s,%d,%lf,%llu\n",head->num,head->name,head->phno,
				head->usrName,head->pass,head->rfid,head->pin,head->cardStat,head->bal,head->tranCnt);

		//save bank statement
		char spName[30];
		sprintf(spName,"../dataz/%llu.csv",head->num);
		FILE *sp=fopen(spName,"w");
		Tran *t=head->tranHist;
		while(t){
			fprintf(sp,"%llu,%lf,%c\n",t->id,t->amt,t->type);
			t=t->nxt;
		}
		fclose(sp);
		head=head->nxt;
	}

	fclose(fp);
}
//
//
void saveFile(Acc *head){
        unsigned int dd,mon,yy,hh,mm;
        u64 dum;
        FILE *fp=fopen("../filez/DataBase.csv","w");

        fprintf(fp,"Account ID,Holder's name,Mobile no.,Username,Password,ATM card no.,ATM pin,Card Satus,Balance,Transactions count\n");
        while(head){
                fprintf(fp,"%llu,%s,%llu,%s,%s,%s,%s,%s,%lf,%llu\n",head->num,head->name,head->phno,
                                head->usrName,head->pass,head->rfid,head->pin,(head->cardStat)?"ACTIVE":"BLOCKED"
                                ,head->bal,head->tranCnt);

                //save bank statement
                char spName[40];
                sprintf(spName,"../filez/%llu.csv",head->num);
                FILE *sp=fopen(spName,"w");
                Tran *t=head->tranHist;
                fprintf(sp,"Date,Time,Transaction ID,Amount,Type\n");
                while(t){
                        dum=(t->id)/100000;
                        mm=dum%100;
                        dum/=100;
                        hh=dum%100;
                        dum/=100;
                        dd=dum%100;
                        dum/=100;
                        mon=dum%100;
                        dum/=100;
                        yy=dum;
                        fprintf(sp,"%u/%u/%u,%u:%u,%llu,%lf,",dd,mon,yy,hh,mm,t->id,t->amt);
                        if(t->type==DEPOSIT)            fprintf(sp,"%s\n","Deposit");
                        else if(t->type==WITHDRAW)      fprintf(sp,"%s\n","Withdraw");
                        else if(t->type==TRANSFER_IN)   fprintf(sp,"%s\n","Tranfer IN");
                        else if(t->type==TRANSFER_OUT)  fprintf(sp,"%s\n","Tranfer OUT");
                        t=t->nxt;
                }
                fclose(sp);
                head=head->nxt;
        }
        fclose(fp);
}

//
