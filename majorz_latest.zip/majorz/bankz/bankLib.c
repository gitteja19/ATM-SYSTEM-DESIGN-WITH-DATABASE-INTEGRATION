
#include <stdio.h>
#include <stdio_ext.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include "bankLib.h"

#include <termios.h>
#include <fcntl.h>


const int szDb=(sizeof(u64)*2+sizeof(f64)+sizeof(char)*(MAX_USRN_LEN+MAX_PASS_LEN));

void loginMenu(void){
	printf(BPINK"\n-------------WELCOME TO @JET BANK--------------\n");
	printf("Please enter login credentials.\n"RESET);
}

void adminMenu(void){
	printf(BPINK"\nHI ADMIN:\n"
                        "[KEY]  : ACTION\n"
                        "c/C    : Create New account.\n"
                        "u/U    : Update Existing account.\n"
                        "h/H    : Transaction history.\n"
                        "w/W    : Withdraw amount.\n"
                        "d/D    : Deposit amount.\n"
                        "b/B    : Balance enquery.\n"
                        "t/T    : Transfer money.\n"
			"x/X    : Activate card.\n"
                        "e/E    : Display all accounts details.\n"
                        "f/F    : Finding/searching for specific account.\n"
                        "q/Q    : Quit from app.\n"BYELLOW
                        "Enter choice:"RESET);
}

void userMenu(void){
	printf(BPINK"\nHI CUSTOMER:\n"
                        "[KEY]  : ACTION\n"
                        "h/H    : Transaction history.\n"
                        "w/W    : Withdraw amount.\n"
                        "d/D    : Deposit amount.\n"
                        "b/B    : Balance enquery.\n"
                        "t/T    : Transfer amount.\n"
                        "q/Q    : Quit from app.\n"BYELLOW
                        "Enter choice:"RESET);

}

void menu(void){
	printf("\n------------------MENU--------------------------\n"
	                "[KEY]	: ACTION\n"
			"c/C 	: Create New account.\n"
			"u/U    : Update Old account info.\n"
			"h/H 	: Transaction history.\n"
			"w/W 	: Withdraw amount.\n"
			"d/D 	: Deposit amount.\n"
			"b/B	: Balance enquery.\n"
			"t/T 	: Transfer money.\n"
			"e/E	: Display all accounts details.\n"
			"f/F	: Finding/searching for specific account.\n"
			"q/Q	: Quit from app.\n"
			"Enter choice:");
}

Acc* isValid(Acc *head,char *usr,char *pass){
	while(head){
		if((!strcmp(usr,head->usrName))&&(!strcmp(pass,head->pass)))
			 break;
		head=head->nxt;
	}
	return head;
}

void newAcc( Acc **head){
	char *temp=NULL,flag=1;
	double d;
	Acc *new=calloc(1,sizeof(Acc));
        new->tranHist=NULL;
	new->tranCnt=0;
	new->num=getUnqId(*head);
	printf("Enter Name:");
	__fpurge(stdin);
	new->name=getStr();
	if(strlen(new->name)<3){
		puts("no name");
		free(new->name);
		free(new);
		return;
	}
	format(new->name);

	flag=1;
	while(flag){
		if(flag!=1)puts("Mobile must be 10 digit, and min:60000 0000"); 
		printf("Enter Mobile No.:");
		//char *num=getStr();	
		scanf("%llu",&(new->phno));
		if((new->phno>=6000000000)&&(new->phno<9999999999)){
			//valid
			break;
		}else{
			flag++;
		}
	}

	flag=1;
	while(flag){
		printf("Enter Login Username:");
		temp=getStr();
		if(strlen(temp)>=MAX_USRN_LEN){
			puts("Username too long,try again!!");
			free(temp);
			continue;
		}
		if(isUnq(*head,temp)){
			strcpy(new->usrName,temp);
			free(temp);
			flag=0;
		}else{
			puts("User name aldready exits!");
			puts("Try differnt one.");
			free(temp);
		}
		
	}
	flag=1;
	while(flag){
		if(flag>1)puts("Password mismatch!! Retry.");
		printf("Enter Login Password:");
		temp=getStr();
		if(strlen(temp)>=MAX_PASS_LEN){
                        puts("Password too long,try again!!");
			flag=1;
			free(temp);
                        continue;
                }
		strcpy(new->pass,temp);
		free(temp);
		printf("Re-enter Login Password:");
		temp=getStr();
		flag=(strcmp(temp,new->pass)?flag+1:0);
	}
	free(temp);
        flag=1;
        while(flag){
                if(flag>1)printf("8 digit RFID please:");
		else printf("Enter RFID card number:");
		
		temp=getStr();
                if(strlen(temp)!=8){
                        puts("try again!!");
                        flag++;
			free(temp);
                        continue;
                }else{
			if(isNewRFID(*head,temp)){
				strcpy(new->rfid,temp);
				free(temp);
				break;
			}else{
				puts("RFID aldready in use!!");
				flag++;
				free(temp);
			}
		}
        }
        
	flag=1;
        while(flag){
                if(flag>1)puts("Pin mismatch!! Retry.");
                printf("Enter ATM Pin:");
                temp=getStr();
                if(strlen(temp)!=4){
                        puts("4 digit Pin please,try again!!");
                        flag=1;
			free(temp);
                        continue;
                }
                strcpy(new->pin,temp);
                free(temp);
                printf("Re-enter ATM Pin:");
                temp=getStr();
                flag=(strcmp(temp,new->pin)?flag+1:0);
        }
	free(temp);
	new->cardStat=1;//active

	flag=1;
	while(flag){
		if(flag>1)printf("Enter an posivite amount:");
		else printf("Enter Opening Amount:");
		scanf("%lf",&d);//must update trancs
		if(d>0){
			new->bal=d;
			break;
		}else flag++;
	}
	addTran(new,new->bal,DEPOSIT);//0

	dispAcc(new);
	//add to database
	new->nxt=*head;
	*head=new;
	puts(BGREEN"Account Created."RESET);
	
}

int isUnq(Acc *head,char *str){
	if(!strcmp(str,ADMIN_USRN)) return 0;
	while(head){
		if(!strcmp(str,head->usrName)) return 0;
		head=head->nxt;
	}
	return 1;
}

int isNewRFID(Acc *head,char *rf){
	while(head){
		if(!strcmp(rf,head->rfid)) return 0;
		head=head->nxt;
	}
	return 1;
}

u64 getUnqId(Acc *head){
	u64 num;
	Acc *temp=NULL;
	int found=1;
	while(found){
		srand(getpid()+ (unsigned int)head);
		//18 digit unq ID	
		num=getTimeStamp()*10000 +(rand()%10000);
		temp=head;
		found=0;
		while(temp){
			if(num==temp->num){
				found=1;
				break;
			}
			temp=temp->nxt;
		}
	}
	return num;
}

u64 getTimeStamp(void){
    time_t rawtime;
    struct tm *timeinfo;

    // Get current UTC time
    time(&rawtime);

    // Convert to IST (UTC +5:30)
   // rawtime +=19800;  // 19800 seconds = 5 hours 30 minutes
    timeinfo =localtime(&rawtime);

    // Format as YYYYMMDDHHMMSS (14-digit ID)
    u64 timeStamp =
        (timeinfo->tm_year+1900)*10000000000ULL+
	(timeinfo->tm_mon+1)*100000000ULL+
	timeinfo->tm_mday*1000000ULL+
	timeinfo->tm_hour*10000ULL+
	timeinfo->tm_min *100ULL+
	timeinfo->tm_sec;

    return timeStamp;
}

char *getStr(void){
	char buff[NAME_LEN]={0};
	fflush(stdout);
	__fpurge(stdin);
	scanf("%[^\n]",buff);
	return strdup(buff);
}

char getch(void){
    struct termios oldt, newt;
    int oldf;
    int ch;

    // Save terminal settings
    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;

    // Disable canonical mode and echo
    newt.c_lflag &= ~(ICANON);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);

    // Set non-blocking mode
    oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
    fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);

    ch = getchar();

    // Restore settings
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    fcntl(STDIN_FILENO, F_SETFL, oldf);

    if (ch != EOF) {
        return ch;
    }

    return -1; // No input
}

/*
char getKey(void) {
    struct termios oldt, newt;
    char key[3] = {0}, ch;
    int i = 0;

    // Turn off canonical mode and echo
    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);

    while (i < 3) {
        read(STDIN_FILENO, &ch, 1);

        if (ch == 8 || ch == 127) {  // Backspace handling
            if (i > 0) {
                i--;
                printf("\b \b");  // Move back, print space, move back
                fflush(stdout);
            }
        }
        else if (ch == '\n' || ch == '\r') {  // Enter
            key[i] = '\0';
            printf("\n");  // Move to next line
            break;
        }
        else {
            key[i++] = ch;
            printf("%c", ch);  // Echo character
            fflush(stdout);
        }
    }

    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);  // Restore terminal settings

    if (i == 3 || key[1] != '\0') return '\0';  // Check for invalid input
    CAPS(key[0]);  // Uncomment if you have this macro
    return key[0];
}
*/
char getKey(void){
	char key[3],ch;
	int i=0;
	fflush(stdout);
	__fpurge(stdin);
	key[0]=getchar();
	/*
	while(i<3){
		while((ch=getch())==-1);
		key[i]=ch;
		if((ch=='\b')||(ch==127)){
			if(i)i--;
			key[i]=0;
		}else if(ch=='\n'){
			key[i]='\0';
			break;
		}else i++;
	}
	if((i==3)||(key[1]!='\0')) return '\0';
	*/
	CAPS(key[0]);
	puts("");
	return key[0];
}
void format(char *str){
	CAPS(str[0]);
	str++;
	while(*str){
		if(*(str-1)==' ')CAPS(*str);
		str++;
	}
}
///

///
void updateAcc(Acc **head,Acc *usr){
	char key,*temp=NULL;
	int flag=1;
	accMenu();

	key=getKey();
	__fpurge(stdin);
	puts("");
	switch(key){
		case 'P':printf("Enter New phone number:");
			 scanf("%llu",&(usr->phno));
			 puts(BGREEN"Mobile Updated."RESET);
			 break;
		case 'O':printf("Enter New Holder name:");
			 __fpurge(stdin);
			 temp=getStr();
			 if(strlen(temp)<3){
				 puts("invalid name");
				 free(temp);
				 return;
			 }
			 format(temp);
			 usr->name=temp;
			 puts(BGREEN"Name Updated."RESET);
			 break;
		case 'U':flag=1;
			 while(flag){
				 printf("Enter New Username:");
				 temp=getStr();
				 if(strlen(temp)>MAX_USRN_LEN){
					 puts("Username too long,try again!!");
					 continue;
				 }
				 if(!strcmp(temp,usr->usrName)){
					puts("New Username is same as your Existing Username.");
					puts("Do you wanna change the username?(y/n):");
					key=getKey();
					if(key=='Y'){
						free(temp);
						continue;
					}else if(key=='N'){
						free(temp);
						return;
					}else{
						//stupid
					}

				 }else if(isUnq(*head,temp)){
					 strcpy(usr->usrName,temp);
					 free(temp);
					 flag=0;
				 }else{
					 puts("User name aldready exits!");
					 puts("Try differnt one.");
				 }
			 }
			 if(!flag)puts(BGREEN"Username Updated."RESET);
			 break;
		case 'Q':printf("Enter old password:");
			 temp=getStr();
			 if(strcmp(temp,usr->pass)){
				 puts("Wrong password!!");
				 break;
			 }
			 flag=1;
			 while(flag){
				 if(flag>1)puts("Password mismatch!! Retry.");
				 printf("Enter New Login Password:");
				 temp=getStr();
				 if(strlen(temp)>=MAX_PASS_LEN){
					 puts("Password too long,try again!!");
					 flag=1;
					 continue;
				 }
				 strcpy(usr->pass,temp);
				 free(temp);
				 printf("Re-enter New Login Password:");
				 temp=getStr();
				 flag=(strcmp(temp,usr->pass)?flag+1:0);
			 }
			 puts(BGREEN"Password Updated."RESET);
			 break;
		case 'A':printf("Enter Old ATM Pin:");
                         temp=getStr();
                         if(strcmp(temp,usr->pin)){
                                 puts("Wrong pin!!");
				 free(temp);
                                 break;
                         }
                         flag=1;
			 free(temp);
                         while(flag){
                                 if(flag>1)puts("Pin mismatch!! Retry.");
                                 printf("Enter New ATM Pin:");
                                 temp=getStr();
                                 if(strlen(temp)!=4){
                                         puts("4 digit pin pls,try again!!");
                                         flag=1;
					 free(temp);
                                         continue;
                                 }
                                 strcpy(usr->pin,temp);
                                 free(temp);
                                 printf("Re-enter New ATM Pin:");
                                 temp=getStr();
                                 flag=(strcmp(temp,usr->pin)?flag+1:0);
			 	 free(temp);
                         }
                         puts(BGREEN"Pin Updated."RESET);
                         break;
		default:puts("invalid input.");
			break;
	}
}


void accMenu(void){
	printf(BBLUE"\nChange:\n"
			"[KEY]-ACTION\n"
			"p/P  -Phone number.\n"
			"o/O  -Holder's name.\n"
			"u/U  -Username.\n"
			"q/Q  -Password.\n"BYELLOW
			"Enter choice:"RESET);
}
///

///
void dispAcc(Acc *usr){
	puts(BBLUE"\n==:Account Details:=="RESET);
	printf("AccNo.:%llu\n",usr->num);
	printf("Name  :%s\n",usr->name);
	printf("Ph.No.:%llu\n",usr->phno);
	printf("Balanc:%lf\n",usr->bal);
	printf("Usrnam:%s\n",usr->usrName);
	printf("Passwd:%s\n",usr->pass);
	printf("RFID  :%s\n",usr->rfid);
	printf("Pin   :%s\n",usr->pin);
	printf("Card  :%s\n",(usr->cardStat==1)?"ACTIVE":"BLOCKED");
	printf("TranNo:%llu\n",usr->tranCnt);
}
///

///
Acc* getAcc(Acc *head){
	u64 num=0;
	char key='\0',*str=NULL;
	printf( BBLUE"Find by:\n"
		"[KEY]-ACTION\n"
		"p/P  -Phone number.\n"
		"n/N  -Account number.\n"
		"o/O  -Holder name.\n"
		"u/U  -Username.\n"BYELLOW
		"Enter choice:"RESET);
	key=getKey();
	__fpurge(stdin);
	puts("");
	switch(key){
		case 'P':printf("Enter phone number:");
			 scanf("%llu",&num);
			 while(head){
				if(num==head->phno)break;
				 head=head->nxt;
			 }
			 break;
		case 'N':printf("Enter account number:");
			 scanf("%llu",&num);
			 while(head){
				if(num==head->num)break;
				 head=head->nxt;
			 }
			 break;
		case 'O':printf("Enter holder name:");
			 str=getStr();
			 format(str);
			 while(head){
				if(!strcmp(str,head->name))break;
				 head=head->nxt;
			 }
			 free(str);
			 break;
		case 'U':printf("Enter username:");
			 str=getStr();
			 while(head){
				if(!strcmp(str,head->usrName))break;
				 head=head->nxt;
			 }
			 free(str);
			 break;
		default:puts("invalid choice");
			head=NULL;
			break;
	}
	return head;
}
///

///
void dltAcc(Acc **head){
	if(!(*head))return;

	//travese to acc
	//delete
}
///

///
void balance(Acc *usr){
	printf("\nAccount Number : %llu\n",usr->num);
	printf("Holder Name    : %s\n",usr->name);
	printf("Current Balance: %+lf Rs/-\n",usr->bal);
}
///

///
void deposit(Acc *usr){
	f64 amt=0;
	printf("\nEnter Deposit Amount:");
        scanf("%lf",&amt);
	
	if(amt<=0){
		puts("Amount cannot be negative!!");
                puts("Try again!!");
	}else if(amt<MAX_DEPOSIT){
		usr->bal += amt;
		//update 2 transc
		addTran(usr,+amt,DEPOSIT);
		puts(BGREEN"Amount Deposited."RESET);
	}else{
		puts("Amount exceeds Max.Deposit limit!!");
		puts("Try again!!");
	}
}
///

///
void withdraw(Acc *usr){
	f64 amt=0;
	printf("\nEnter Withdrawal Amount:");
	scanf("%lf",&amt);
	if(amt<=0){
                puts("Amount cannot be negative!!");
                puts("Try again!!");
        }else if(amt<MAX_WITHDRAW){
		if(amt<=usr->bal){
			usr->bal -= amt;
			//update 2 transc
			addTran(usr,-amt,WITHDRAW);//1
			puts(BGREEN"Amount Withdrawn."RESET);
		}else{
			puts("Low Balance!!");
		}
	}else{
		puts("Amount exceeds Max.Withdraw limit!!");
		puts("Try again!!");
	}
}
///

///
void transfer(Acc *from,Acc *to){
        f64 amt=0;
        printf("\nEnter Transfer Amount:");
        scanf("%lf",&amt);
        if(amt<=0){
                puts("Amount cannot be negative!!");
                puts("Try again!!");
        }else if(amt<MAX_TRANSFER){
                if(amt<=from->bal){
                        from->bal -= amt;
			to->bal   += amt;
                        //update 2 transc of both
			addTran(to,+amt,TRANSFER_IN);
			addTran(from,-amt,TRANSFER_OUT);
                        puts(BGREEN"Amount Transfered."RESET);
                }else{
                        puts("Low Balance!!");
                }
        }else{
                puts("Amount exceeds Max.Transfer limit!!");
                puts("Try again!!");
        }
}
///

///
void addTran(Acc *usr,f64 amt,char type){
	Tran *new=calloc(1,sizeof(Tran));
	new->amt=amt;
	new->id =getTranId(usr);
	new->type=type;
	new->nxt=NULL;

	new->nxt=usr->tranHist;
	usr->tranHist=new;

	(usr->tranCnt)++;
}

u64 getTranId(Acc *usr){
	//17 digit unq TranID
	srand(usr->num);
        return getTimeStamp()*1000 +(rand()%1000);
}
///

///
void statement(Acc *usr){
    Tran *temp = usr->tranHist;
    if (temp) {
        printf(BCYAN"\n%-20s%-23s%-12s\n", "Transaction ID", "Amount (Rs)","Type");
        puts("----------------------------------------");
        while (temp) {
            printf("%-20llu%-+20.2lf",temp->id,temp->amt);
	    if(temp->type==DEPOSIT)	 printf("%-12s\n","Deposit");
	    else if(temp->type==WITHDRAW)printf("%-12s\n","Withdraw");
	    else if(temp->type==TRANSFER_IN)printf("%-12s\n","Tranfer IN");
	    else if(temp->type==TRANSFER_OUT)printf("%-12s\n","Tranfer OUT");
            temp = temp->nxt;
        }
    } else {
        puts("No Transaction History!");
    }
    printf(RESET);
}
///

///
void database(Acc *head){
	if(!head){
		puts("Empty Database!!WTF");
		return;
	}
	printf(BBLUE"\n%-20s|%-40s|%-14s|%-12s\n",
			"Account ID",
			"Holder Name",
			"Mobile(+91)",
			"Transactions"RESET);
	while(head){
		printf("%-20llu|%-40s|+91-%-10llu|%-12llu\n",
				head->num,
				head->name,
				head->phno,
				head->tranCnt);
		head=head->nxt;
	}
}
///

// "%llu,%lf,%c",id,amt,type
// "%llu,%s,%llu,%s,%s,%s,%s,%d,%lf,%llu",num,name,phno,usrName,pass,rfid,pin,cardStat,bal,tranCnt

///
//

void saveData(Acc *head){

	FILE *fp=fopen("../dataz/Db.csv","w");
	
	while(head){
		fprintf(fp,"%llu,%s,%llu,%s,%s,%s,%s,%d,%lf,%llu\n",head->num,head->name,head->phno,
				head->usrName,head->pass,head->rfid,head->pin,head->cardStat,head->bal,head->tranCnt);
		
		//save bank statement
		char spName[30];
		sprintf(spName,"../dataz/%llu.csv",head->num);
		FILE *sp=fopen(spName,"w");
		Tran *t=head->tranHist;
		while(t){
			fprintf(sp,"%llu,%lf,%c\n",t->id,t->amt,t->type);
			t=t->nxt;
		}
		fclose(sp);
		head=head->nxt;
	}

	fclose(fp);
}
void syncData(Acc **head){
	FILE *fp=fopen("../dataz/Db.csv","r");
	int d;
	char buf[100];
	if(!fp){
		perror("Sync");	
		return;
	}
	puts("syncing");
	Acc temp,*tail=NULL;

	temp.nxt=NULL;
	temp.tranHist=NULL;
	temp.tranCnt=0;
        while(fscanf(fp,"%llu,%[^,],%llu,%[^,],%[^,],%[^,],%[^,],%d,%lf,%llu",&(temp.num),buf,&(temp.phno),temp.usrName,temp.pass,temp.rfid,temp.pin,&(temp.cardStat),&(temp.bal),&(temp.tranCnt))==10){
		temp.name=strdup(buf);
		/*

		printf("%llu,%s,%llu,%s,%s,%s,%s,%d,%lf,%llu\n",
				temp.num, temp.name, temp.phno,
				temp.usrName, temp.pass, temp.rfid,
				temp.pin, temp.cardStat, temp.bal, temp.tranCnt);

		printf("d=%d\n",d);
		while(1);
		*/

		Acc *new =calloc(1,sizeof(Acc));
		memmove(new,&temp,sizeof(Acc));
		if(!(*head))*head=new;
		if(tail)tail->nxt=new;
		tail=new;
		
                //save bank statement
                char spName[30];
                sprintf(spName,"../dataz/%llu.csv",new->num);
                FILE *sp=fopen(spName,"r");
		if(!sp)continue;
                Tran *th=NULL,*tt=NULL,tm;
		int cnt=0;
		tm.nxt=NULL;
                while(fscanf(sp,"%llu,%lf,%c",&(tm.id),&(tm.amt),&(tm.type))==3){
			Tran *c=malloc(sizeof(Tran));
			cnt++;
                        memmove(c,&tm,sizeof(Tran));
			if(!th)th=c;
			if(tt)tt->nxt=c;
                        tt=c;
                }
		new->tranHist=th;
		new->tranCnt=cnt;
                fclose(sp);
        }

        fclose(fp);
}


void saveFile(Acc *head){
        unsigned int dd,mon,yy,hh,mm;
        u64 dum;
        FILE *fp=fopen("../filez/DataBase.csv","w");

        fprintf(fp,"Account ID,Holder's name,Mobile no.,Username,Password,ATM card no.,ATM pin,Card Satus,Balance,Transactions count\n");
        while(head){
                fprintf(fp,"%llu,%s,%llu,%s,%s,%s,%s,%s,%lf,%llu\n",head->num,head->name,head->phno,
                                head->usrName,head->pass,head->rfid,head->pin,(head->cardStat)?"ACTIVE":"BLOCKED"
                                ,head->bal,head->tranCnt);

                //save bank statement
                char spName[40];
                sprintf(spName,"../filez/%llu.csv",head->num);
                FILE *sp=fopen(spName,"w");
                Tran *t=head->tranHist;
                fprintf(sp,"Date,Time,Transaction ID,Amount,Type\n");
                while(t){
                        dum=(t->id)/100000;
                        mm=dum%100;
                        dum/=100;
                        hh=dum%100;
                        dum/=100;
                        dd=dum%100;
                        dum/=100;
                        mon=dum%100;
                        dum/=100;
                        yy=dum;
                        fprintf(sp,"%u/%u/%u,%u:%u,%llu,%lf,",dd,mon,yy,hh,mm,t->id,t->amt);
                        if(t->type==DEPOSIT)            fprintf(sp,"%s\n","Deposit");
                        else if(t->type==WITHDRAW)      fprintf(sp,"%s\n","Withdraw");
                        else if(t->type==TRANSFER_IN)   fprintf(sp,"%s\n","Tranfer IN");
                        else if(t->type==TRANSFER_OUT)  fprintf(sp,"%s\n","Tranfer OUT");
                        t=t->nxt;
                }
                fclose(sp);
                head=head->nxt;
        }
        fclose(fp);
}

/*
void saveData(Acc *head) {
    FILE *fp = fopen("../dataz/Db.csv", "w");
    if (!fp) return;

    while (head) {
        fprintf(fp, "%llu,%s,%llu,%s,%s,%s,%s,%d,%lf,%llu\n",
                head->num, head->name, head->phno,
                head->usrName, head->pass, head->rfid,
                head->pin, head->cardStat, head->bal, head->tranCnt);

	printf("%llu,%s,%llu,%s,%s,%s,%s,%d,%lf,%llu\n",
                head->num, head->name, head->phno,
                head->usrName, head->pass, head->rfid,
                head->pin, head->cardStat, head->bal, head->tranCnt);
        // Save bank statement
        char spName[50];
        sprintf(spName, "../dataz/%llu.csv", head->num);
        FILE *sp = fopen(spName, "w");
        if (!sp) {
            head = head->nxt;
            continue;
        }

        Tran *t = head->tranHist;
        while (t) {
            fprintf(sp, "%llu,%lf,%c\n", t->id, t->amt, t->type);
            t = t->nxt;
        }
        fclose(sp);
        head = head->nxt;
    }

    fclose(fp);
}

*/

///
